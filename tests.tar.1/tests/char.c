
char* g;

void main()
{
	char* h;
	h = "Hello world";

	printf("h[6]=%c\n", h[6]);

	g = "This is a great class!!";

	printf("g[11]=%c\n", g[11]);
}

