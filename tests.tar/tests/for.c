
long i;

void main()
{
	for (i=0; i<15; i= i+1) {
		printf("i=%d\n", i);
	}
		
	printf("OK\n");
}

