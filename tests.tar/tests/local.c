

void main()
{
	long l;
	l = 6;
	printf("l=%d\n", l);
}

