
long g;

void main()
{
	g = 8;
	printf("g=%d\n", g);
}

